CREATE TRIGGER TR_SPRAWDZ_POPRAWNOSC_DATY_ORAZ_DOSTEPNOSC_WYNAJECIA
    ON NAJEM_INDYWIDUALNY
    INSTEAD OF INSERT
    AS
BEGIN
    DECLARE @FROM date;
    DECLARE @TO date;
    DECLARE @NIERUCH bigint;
    DECLARE @UUID varchar(255);
    SELECT @UUID = inserted.UUID, @FROM = inserted.DATA_OD, @TO = inserted.DATA_DO, @NIERUCH = inserted.ID_NIERUCHOMOSC
    FROM inserted;

    IF (@TO < @FROM)
        BEGIN
            RAISERROR ('Wrong dates!',17,1);
        END
    ELSE
        IF EXISTS(SELECT *
                  FROM NAJEM_INDYWIDUALNY
                  WHERE NAJEM_INDYWIDUALNY.ID_NIERUCHOMOSC = @NIERUCH
                    AND NAJEM_INDYWIDUALNY.DATA_OD >= @FROM
                    AND NAJEM_INDYWIDUALNY.DATA_DO <= @TO)
            BEGIN
                RAISERROR ('Nieruchomość jest wynajmowana w tym terminie!',17,1);
            END
        ELSE
            BEGIN


                INSERT INTO NAJEM_INDYWIDUALNY (UUID, ID_KLIENT_INDYWIDUALNY, DATA_OD, DATA_DO, ID_NIERUCHOMOSC,
                                                WIELKOSC_RABATU, ID_RACHUNEK, ILE_DNI)
                SELECT inserted.UUID,
                       inserted.ID_KLIENT_INDYWIDUALNY,
                       inserted.DATA_OD,
                       inserted.DATA_DO,
                       inserted.ID_NIERUCHOMOSC,
                       dbo.FN_OBLICZ_RABAT(inserted.DATA_OD, inserted.DATA_DO),
                       null,
                       DATEDIFF(day, inserted.DATA_OD, inserted.DATA_DO)
                FROM inserted;
            END

    IF EXISTS(SELECT * FROM NAJEM_INDYWIDUALNY WHERE UUID = @UUID)
        BEGIN

            SELECT N.*
            FROM NAJEM_INDYWIDUALNY
                     JOIN NIERUCHOMOSC N on NAJEM_INDYWIDUALNY.ID_NIERUCHOMOSC = N.ID_NIERUCHOMOSC
            WHERE NAJEM_INDYWIDUALNY.UUID = @UUID;

        END

END
go

