CREATE FUNCTION FN_OBLICZ_RABAT(@FROM date, @TO date) RETURNS decimal(2, 2) AS
BEGIN
    IF (DATEDIFF(month, @FROM, @TO) <= 1)
        BEGIN
            RETURN 0.00
        END
    IF (DATEDIFF(month, @FROM, @TO) <= 3)
        BEGIN
            RETURN 0.05
        END
    IF (DATEDIFF(month, @FROM, @TO) > 3 AND DATEDIFF(month, @FROM, @TO) <= 12)
        BEGIN
            RETURN 0.10
        END
    IF (DATEDIFF(month, @FROM, @TO) > 12)
        BEGIN
            RETURN 0.15
        END
    RETURN 0.00;
END
go

